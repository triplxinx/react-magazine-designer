import React, { useRef, useState, useEffect, useCallback } from 'react';
import styled from 'styled-components';
import Draggable from 'react-draggable';
import { ResizableBox } from 'react-resizable';

import 'react-resizable/css/styles.css';

const Container = styled.div`
  position: absolute;
  box-sizing: border-box;
  border: 1px solid transparent;
  background: transparent;

  &:focus-within {
    border-color: #1abc9c;
    box-shadow: 0 0 5px #1abc9c;
  }
`;

const Img = styled.img`
  width: 100%;
  height: 100%;
  object-fit: contain;
  user-select: none;
  pointer-events: none;
`;

const Controls = styled.div`
  position: absolute;
  bottom: 2px;
  left: 2px;
  display: flex;
  gap: 4px;
  z-index: 10;
`;

const Button = styled.button`
  background: #34495e;
  border: none;
  color: white;
  padding: 2px 6px;
  font-size: 12px;
  border-radius: 3px;
  cursor: pointer;

  &:hover {
    background: #1abc9c;
  }
`;

const DeleteButton = styled.button`
  position: absolute;
  top: -10px;
  right: -10px;
  background: #e74c3c;
  border: none;
  color: white;
  border-radius: 50%;
  width: 20px;
  height: 20px;
  font-weight: bold;
  cursor: pointer;
  user-select: none;
  z-index: 10;

  &:hover {
    background: #c0392b;
  }
`;

function ImageElement({
  element,
  containerWidth,
  containerHeight,
  marginPx,
  gridSizePx,
  onDragStop,
  onResizeStop,
  onUpdate,
  onDelete
}) {
  const [imageSrc, setImageSrc] = useState(element.src);
  const [isFocused, setIsFocused] = useState(false);
  const containerRef = useRef(null);
  const fileInputRef = useRef(null);

  // Handle drag stop
  const handleDragStop = (e, data) => {
    let x = data.x;
    let y = data.y;

    // Clamp within container bounds minus margin
    x = Math.max(marginPx, Math.min(x, containerWidth - marginPx - element.width));
    y = Math.max(marginPx, Math.min(y, containerHeight - marginPx - element.height));

    onDragStop(element.id, x, y);
  };

  // Handle resize stop
  const handleResizeStop = (event, { size }) => {
    let width = size.width;
    let height = size.height;

    // Clamp sizes
    const maxWidth = containerWidth - element.x - marginPx;
    const maxHeight = containerHeight - element.y - marginPx;

    width = Math.min(width, maxWidth);
    height = Math.min(height, maxHeight);

    onResizeStop(element.id, width, height);
  };

  // Upload image file
  const onUploadClick = () => {
    if (fileInputRef.current) {
      fileInputRef.current.value = null;
      fileInputRef.current.click();
    }
  };

  const onFileChange = (e) => {
    const file = e.target.files && e.target.files[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      alert('Only image files are allowed.');
      return;
    }

    const maxSizeMB = Number(process.env.REACT_APP_MAX_IMAGE_SIZE_MB) || 10;
    if (file.size > maxSizeMB * 1024 * 1024) {
      alert(`Image size exceeds ${maxSizeMB}MB limit.`);
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      setImageSrc(reader.result);
      onUpdate(element.id, { src: reader.result });
    };
    reader.readAsDataURL(file);
  };

  // Handle keyboard focus border
  const onFocus = () => {
    setIsFocused(true);
  };

  const onBlur = () => {
    setIsFocused(false);
  };

  // Clamp position within container bounds on mount or element update
  useEffect(() => {
    let x = element.x;
    let y = element.y;

    x = Math.max(marginPx, Math.min(x, containerWidth - marginPx - element.width));
    y = Math.max(marginPx, Math.min(y, containerHeight - marginPx - element.height));

    if (x !== element.x || y !== element.y) {
      onUpdate(element.id, { x, y });
    }
  }, [
    element.x,
    element.y,
    element.width,
    element.height,
    containerWidth,
    containerHeight,
    marginPx,
    onUpdate,
    element.id
  ]);

  return (
    <Draggable
      bounds={{
        left: marginPx,
        top: marginPx,
        right: containerWidth - marginPx - element.width,
        bottom: containerHeight - marginPx - element.height
      }}
      position={{ x: element.x, y: element.y }}
      grid={[gridSizePx, gridSizePx]}
      onStop={handleDragStop}
      handle=".handle"
    >
      <Container
        ref={containerRef}
        style={{
          width: element.width,
          height: element.height,
          borderColor: isFocused ? '#1abc9c' : 'transparent'
        }}
        tabIndex={0}
        aria-label="Image element"
        onFocus={onFocus}
        onBlur={onBlur}
      >
        <DeleteButton
          aria-label="Delete image element"
          onClick={() => onDelete(element.id)}
          type="button"
        >
          &times;
        </DeleteButton>
        <ResizableBox
          width={element.width}
          height={element.height}
          minConstraints={[50, 50]}
          maxConstraints={[
            containerWidth - element.x - marginPx,
            containerHeight - element.y - marginPx
          ]}
          onResizeStop={handleResizeStop}
          handle={<span className="react-resizable-handle react-resizable-handle-se" />}
          resizeHandles={['se']}
        >
          <Img
            className="handle"
            src={imageSrc}
            alt="Magazine element"
            draggable={false}
            decoding="async"
          />
        </ResizableBox>
        <Controls>
          <Button onClick={onUploadClick} type="button" aria-label="Upload new image">
            Replace Image
          </Button>
          <input
            type="file"
            accept="image/*"
            ref={fileInputRef}
            style={{ display: 'none' }}
            onChange={onFileChange}
            aria-hidden="true"
            tabIndex={-1}
          />
        </Controls>
      </Container>
    </Draggable>
  );
}

export default React.memo(ImageElement);
