import React, { useState, useEffect } from 'react';
import styled from 'styled-components';
import Draggable from 'react-draggable';
import { ResizableBox } from 'react-resizable';

import 'react-resizable/css/styles.css';

const Container = styled.div`
  position: absolute;
  box-sizing: border-box;
  border: 1px solid transparent;
  background: transparent;

  &:focus-within {
    border-color: #1abc9c;
    box-shadow: 0 0 5px #1abc9c;
  }
`;

const DeleteButton = styled.button`
  position: absolute;
  top: -10px;
  right: -10px;
  background: #e74c3c;
  border: none;
  color: white;
  border-radius: 50%;
  width: 20px;
  height: 20px;
  font-weight: bold;
  cursor: pointer;
  user-select: none;
  z-index: 10;

  &:hover {
    background: #c0392b;
  }
`;

const Controls = styled.div`
  position: absolute;
  bottom: 2px;
  left: 2px;
  display: flex;
  gap: 6px;
  z-index: 10;
`;

const ColorInput = styled.input`
  width: 36px;
  height: 24px;
  border: none;
  cursor: pointer;
  background: transparent;
`;

function ShapeElement({
  element,
  containerWidth,
  containerHeight,
  marginPx,
  gridSizePx,
  onDragStop,
  onResizeStop,
  onUpdate,
  onDelete
}) {
  const [isFocused, setIsFocused] = useState(false);

  // Clamp position within container bounds on mount or element update
  useEffect(() => {
    let x = element.x;
    let y = element.y;

    x = Math.max(marginPx, Math.min(x, containerWidth - marginPx - element.width));
    y = Math.max(marginPx, Math.min(y, containerHeight - marginPx - element.height));

    if (x !== element.x || y !== element.y) {
      onUpdate(element.id, { x, y });
    }
  }, [
    element.x,
    element.y,
    element.width,
    element.height,
    containerWidth,
    containerHeight,
    marginPx,
    onUpdate,
    element.id
  ]);

  const handleDragStop = (e, data) => {
    let x = data.x;
    let y = data.y;

    x = Math.max(marginPx, Math.min(x, containerWidth - marginPx - element.width));
    y = Math.max(marginPx, Math.min(y, containerHeight - marginPx - element.height));

    onDragStop(element.id, x, y);
  };

  const handleResizeStop = (event, { size }) => {
    let width = size.width;
    let height = size.height;

    const maxWidth = containerWidth - element.x - marginPx;
    const maxHeight = containerHeight - element.y - marginPx;

    width = Math.min(width, maxWidth);
    height = Math.min(height, maxHeight);

    onResizeStop(element.id, width, height);
  };

  const onShapeTypeChange = (e) => {
    onUpdate(element.id, { shapeType: e.target.value });
  };

  const onFillColorChange = (e) => {
    onUpdate(element.id, { fillColor: e.target.value });
  };

  const onStrokeColorChange = (e) => {
    onUpdate(element.id, { strokeColor: e.target.value });
  };

  const onStrokeWidthChange = (e) => {
    const val = parseInt(e.target.value, 10);
    if (!isNaN(val) && val >= 0 && val <= 10) {
      onUpdate(element.id, { strokeWidth: val });
    }
  };

  const onFocus = () => setIsFocused(true);
  const onBlur = () => setIsFocused(false);

  const renderShape = () => {
    const style = {
      fill: element.fillColor,
      stroke: element.strokeColor,
      strokeWidth: element.strokeWidth
    };
    switch (element.shapeType) {
      case 'rectangle':
        return <rect width="100%" height="100%" {...style} />;
      case 'circle': {
        const cx = element.width / 2;
        const cy = element.height / 2;
        const r = Math.min(element.width, element.height) / 2;
        return <circle cx={cx} cy={cy} r={r} {...style} />;
      }
      case 'line':
        return (
          <line
            x1="0"
            y1={element.height}
            x2={element.width}
            y2="0"
            {...style}
          />
        );
      default:
        return <rect width="100%" height="100%" {...style} />;
    }
  };

  return (
    <Draggable
      bounds={{
        left: marginPx,
        top: marginPx,
        right: containerWidth - marginPx - element.width,
        bottom: containerHeight - marginPx - element.height
      }}
      position={{ x: element.x, y: element.y }}
      grid={[gridSizePx, gridSizePx]}
      onStop={handleDragStop}
      handle=".handle"
    >
      <Container
        tabIndex={0}
        style={{
          width: element.width,
          height: element.height,
          borderColor: isFocused ? '#1abc9c' : 'transparent'
        }}
        aria-label="Shape element"
        onFocus={onFocus}
        onBlur={onBlur}
      >
        <DeleteButton
          aria-label="Delete shape element"
          onClick={() => onDelete(element.id)}
          type="button"
        >
          &times;
        </DeleteButton>
        <ResizableBox
          width={element.width}
          height={element.height}
          minConstraints={[30, 30]}
          maxConstraints={[
            containerWidth - element.x - marginPx,
            containerHeight - element.y - marginPx
          ]}
          onResizeStop={handleResizeStop}
          handle={<span className="react-resizable-handle react-resizable-handle-se" />}
          resizeHandles={['se']}
          className="handle"
        >
          <svg
            width="100%"
            height="100%"
            style={{ display: 'block', userSelect: 'none' }}
            aria-hidden="true"
          >
            {renderShape()}
          </svg>
        </ResizableBox>
        {isFocused && (
          <Controls>
            <select
              aria-label="Select shape type"
              value={element.shapeType}
              onChange={onShapeTypeChange}
            >
              <option value="rectangle">Rectangle</option>
              <option value="circle">Circle</option>
              <option value="line">Line</option>
            </select>
            <ColorInput
              type="color"
              aria-label="Fill color"
              value={element.fillColor}
              onChange={onFillColorChange}
              title="Fill color"
            />
            <ColorInput
              type="color"
              aria-label="Stroke color"
              value={element.strokeColor}
              onChange={onStrokeColorChange}
              title="Stroke color"
            />
            <input
              type="number"
              aria-label="Stroke width"
              min="0"
              max="10"
              value={element.strokeWidth}
              onChange={onStrokeWidthChange}
              title="Stroke width (0-10)"
              style={{ width: 40, fontSize: 12 }}
            />
          </Controls>
        )}
      </Container>
    </Draggable>
  );
}

export default React.memo(ShapeElement);
