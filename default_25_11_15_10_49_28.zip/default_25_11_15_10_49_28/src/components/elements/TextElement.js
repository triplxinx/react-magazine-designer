import React, { useRef, useEffect, useState, useCallback } from 'react';
import styled from 'styled-components';
import { ResizableBox } from 'react-resizable';
import Draggable from 'react-draggable';

import 'react-resizable/css/styles.css';

const TextBox = styled.div`
  width: 100%;
  height: 100%;
  overflow: auto;
  outline: none;
  color: ${(props) => props.color};
  font-size: ${(props) => props.fontSize}px;
  font-family: ${(props) => props.fontFamily};
  text-align: ${(props) => props.textAlign};
  font-weight: ${(props) => props.fontWeight};
  font-style: ${(props) => props.fontStyle};
  text-decoration: ${(props) => props.textDecoration};
  word-break: break-word;
  user-select: text;
  cursor: text;
`;

const Container = styled.div`
  position: absolute;
  box-sizing: border-box;
  border: 1px solid transparent;
  background: transparent;

  &:focus-within {
    border-color: #1abc9c;
    box-shadow: 0 0 5px #1abc9c;
    background: #f0fdfa;
  }
`;

const DeleteButton = styled.button`
  position: absolute;
  top: -10px;
  right: -10px;
  background: #e74c3c;
  border: none;
  color: white;
  border-radius: 50%;
  width: 20px;
  height: 20px;
  font-weight: bold;
  cursor: pointer;
  user-select: none;
  z-index: 10;

  &:hover {
    background: #c0392b;
  }
`;

function TextElement({
  element,
  containerWidth,
  containerHeight,
  marginPx,
  gridSizePx,
  onDragStop,
  onResizeStop,
  onUpdate,
  onDelete
}) {
  const [content, setContent] = useState(element.content);
  const containerRef = useRef(null);

  const [isFocused, setIsFocused] = useState(false);

  const handleDragStop = (e, data) => {
    let x = data.x;
    let y = data.y;

    // Clamp within container bounds minus margin
    x = Math.max(marginPx, Math.min(x, containerWidth - marginPx - element.width));
    y = Math.max(marginPx, Math.min(y, containerHeight - marginPx - element.height));

    onDragStop(element.id, x, y);
  };

  const handleResizeStop = (event, { size }) => {
    let width = size.width;
    let height = size.height;

    // Clamp sizes
    const maxWidth = containerWidth - element.x - marginPx;
    const maxHeight = containerHeight - element.y - marginPx;

    width = Math.min(width, maxWidth);
    height = Math.min(height, maxHeight);

    onResizeStop(element.id, width, height);
  };

  const onContentChange = useCallback(() => {
    if (!containerRef.current) return;
    const html = containerRef.current.innerHTML;
    setContent(html);
    onUpdate(element.id, { content: html });
  }, [element.id, onUpdate]);

  // Handle keyboard shortcuts for formatting
  const handleKeyDown = (e) => {
    if (e.ctrlKey || e.metaKey) {
      switch (e.key.toLowerCase()) {
        case 'b':
          e.preventDefault();
          document.execCommand('bold');
          break;
        case 'i':
          e.preventDefault();
          document.execCommand('italic');
          break;
        case 'u':
          e.preventDefault();
          document.execCommand('underline');
          break;
        case 'z':
          e.preventDefault();
          document.execCommand('undo');
          break;
        case 'y':
          e.preventDefault();
          document.execCommand('redo');
          break;
        default:
          break;
      }
    }
  };

  // Focus management for styling border
  const onFocus = () => {
    setIsFocused(true);
  };

  const onBlur = () => {
    setIsFocused(false);
    onContentChange();
  };

  // Clamp position within container bounds on mount or element update
  useEffect(() => {
    let x = element.x;
    let y = element.y;

    x = Math.max(marginPx, Math.min(x, containerWidth - marginPx - element.width));
    y = Math.max(marginPx, Math.min(y, containerHeight - marginPx - element.height));

    if (x !== element.x || y !== element.y) {
      onUpdate(element.id, { x, y });
    }
  }, [
    element.x,
    element.y,
    element.width,
    element.height,
    containerWidth,
    containerHeight,
    marginPx,
    onUpdate,
    element.id
  ]);

  return (
    <Draggable
      bounds={{
        left: marginPx,
        top: marginPx,
        right: containerWidth - marginPx - element.width,
        bottom: containerHeight - marginPx - element.height
      }}
      position={{ x: element.x, y: element.y }}
      grid={[gridSizePx, gridSizePx]}
      onStop={handleDragStop}
      handle=".handle"
    >
      <Container
        style={{
          width: element.width,
          height: element.height
        }}
        tabIndex={0}
        aria-label="Text element"
      >
        <DeleteButton
          aria-label="Delete text element"
          onClick={() => onDelete(element.id)}
          type="button"
        >
          &times;
        </DeleteButton>
        <ResizableBox
          width={element.width}
          height={element.height}
          minConstraints={[50, 30]}
          maxConstraints={[
            containerWidth - element.x - marginPx,
            containerHeight - element.y - marginPx
          ]}
          onResizeStop={handleResizeStop}
          handle={<span className="react-resizable-handle react-resizable-handle-se" />}
          resizeHandles={['se']}
        >
          <TextBox
            className="handle"
            contentEditable
            suppressContentEditableWarning
            onInput={onContentChange}
            onKeyDown={handleKeyDown}
            onFocus={onFocus}
            onBlur={onBlur}
            ref={containerRef}
            spellCheck={true}
            color={element.style.color}
            fontSize={element.style.fontSize}
            fontFamily={element.style.fontFamily}
            textAlign={element.style.textAlign}
            fontWeight={element.style.fontWeight}
            fontStyle={element.style.fontStyle}
            textDecoration={element.style.textDecoration}
            aria-multiline="true"
            role="textbox"
          >
            <div dangerouslySetInnerHTML={{ __html: content }} />
          </TextBox>
        </ResizableBox>
      </Container>
    </Draggable>
  );
}

export default React.memo(TextElement);
