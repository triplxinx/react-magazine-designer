import React, { useEffect, useRef, useState } from 'react';
import styled from 'styled-components';
import TextElement from './elements/TextElement';
import ImageElement from './elements/ImageElement';
import ShapeElement from './elements/ShapeElement';
import { useDroppable, DndContext } from '@dnd-kit/core';
import {
  restrictToParentElement,
  restrictToBounds,
  snapCenterToCursor,
  snapToGrid
} from '@dnd-kit/modifiers';

const CanvasContainer = styled.div`
  position: relative;
  background: white;
  box-shadow: 0 0 10px rgba(0,0,0,0.2);
  user-select: none;
  overflow: visible;
  border: 1px solid #999;
`;

const PageWrapper = styled.div`
  position: relative;
  background: white;
`;

const PageBoundary = styled.div`
  position: relative;
  background: white;
  box-sizing: content-box;
  border: 1px solid #aaa;
  box-shadow: inset 0 0 12px rgba(0,0,0,0.1);
`;

const DPI = 300;
const MM_TO_INCH = 0.0393701;

function mmToPx(mm, dpi = DPI) {
  return Math.round(mm * MM_TO_INCH * dpi);
}

function snapTo(value, gridSize) {
  return Math.round(value / gridSize) * gridSize;
}

function PageCanvas({ page, pageSize, updateElement, deleteElement }) {
  const containerRef = useRef(null);

  // Calculated page dimensions in pixels
  const pageWidthPx = mmToPx(pageSize.width, pageSize.dpi);
  const pageHeightPx = mmToPx(pageSize.height, pageSize.dpi);
  const marginPx = mmToPx(pageSize.margin, pageSize.dpi);

  // Snap grid in pixels (5 mm)
  const gridSizePx = mmToPx(5, pageSize.dpi);

  // Handle drag update for elements
  const handleDragStop = (id, x, y) => {
    const snappedX = snapTo(x, gridSizePx);
    const snappedY = snapTo(y, gridSizePx);
    updateElement(page.id, id, { x: snappedX, y: snappedY });
  };

  // Handle resize update for elements
  const handleResizeStop = (id, width, height) => {
    updateElement(page.id, id, { width, height });
  };

  // Handle style/content updates for elements
  const handleUpdateElement = (id, props) => {
    updateElement(page.id, id, props);
  };

  const handleDeleteElement = (id) => {
    deleteElement(page.id, id);
  };

  if (!page) {
    return (
      <CanvasContainer
        style={{
          width: pageWidthPx,
          height: pageHeightPx
        }}
        aria-label="Empty page"
      >
        <div>No Page Data</div>
      </CanvasContainer>
    );
  }

  return (
    <CanvasContainer
      ref={containerRef}
      style={{
        width: pageWidthPx,
        height: pageHeightPx,
        position: 'relative'
      }}
      aria-label="Magazine page canvas"
    >
      <PageBoundary
        style={{
          width: pageWidthPx,
          height: pageHeightPx,
          boxSizing: 'border-box'
        }}
      >
        {page.elements.map((el) => {
          switch (el.type) {
            case 'text':
              return (
                <TextElement
                  key={el.id}
                  element={el}
                  pageSize={pageSize}
                  containerWidth={pageWidthPx}
                  containerHeight={pageHeightPx}
                  marginPx={marginPx}
                  gridSizePx={gridSizePx}
                  onDragStop={handleDragStop}
                  onResizeStop={handleResizeStop}
                  onUpdate={handleUpdateElement}
                  onDelete={handleDeleteElement}
                />
              );
            case 'image':
              return (
                <ImageElement
                  key={el.id}
                  element={el}
                  pageSize={pageSize}
                  containerWidth={pageWidthPx}
                  containerHeight={pageHeightPx}
                  marginPx={marginPx}
                  gridSizePx={gridSizePx}
                  onDragStop={handleDragStop}
                  onResizeStop={handleResizeStop}
                  onUpdate={handleUpdateElement}
                  onDelete={handleDeleteElement}
                />
              );
            case 'shape':
              return (
                <ShapeElement
                  key={el.id}
                  element={el}
                  pageSize={pageSize}
                  containerWidth={pageWidthPx}
                  containerHeight={pageHeightPx}
                  marginPx={marginPx}
                  gridSizePx={gridSizePx}
                  onDragStop={handleDragStop}
                  onResizeStop={handleResizeStop}
                  onUpdate={handleUpdateElement}
                  onDelete={handleDeleteElement}
                />
              );
            default:
              return null;
          }
        })}
      </PageBoundary>
    </CanvasContainer>
  );
}

export default PageCanvas;
