import React, { useState, useEffect } from 'react';
import styled from 'styled-components';

const ToolbarContainer = styled.div`
  background: #2c3e50;
  color: white;
  padding: 12px 16px;
  display: flex;
  align-items: center;
  gap: 12px;
  flex-wrap: wrap;
  user-select: none;
`;

const Button = styled.button`
  background: #34495e;
  border: none;
  padding: 8px 12px;
  border-radius: 4px;
  color: white;
  cursor: pointer;
  font-weight: 600;
  font-size: 14px;
  transition: background-color 0.2s ease;

  &:hover,
  &:focus {
    background: #1abc9c;
    outline: none;
  }

  &:disabled {
    background: #7f8c8d;
    cursor: not-allowed;
  }
`;

const Select = styled.select`
  background: #34495e;
  border: none;
  color: white;
  padding: 6px 10px;
  border-radius: 4px;
  font-size: 14px;
  cursor: pointer;

  &:focus {
    outline: none;
    background: #1abc9c;
  }
`;

const Label = styled.label`
  font-size: 14px;
  user-select: none;
`;

const PageNavigator = styled.div`
  display: flex;
  align-items: center;
  gap: 6px;
`;

const Input = styled.input`
  width: 40px;
  padding: 4px 6px;
  border-radius: 4px;
  border: none;
  font-size: 14px;
  text-align: center;

  &:focus {
    outline: none;
  }
`;

const pageSizes = {
  A4: { width: 210, height: 297 },
  Letter: { width: 216, height: 279 },
  Legal: { width: 216, height: 356 }
};

function Toolbar({
  addElement,
  pageSize,
  changePageSize,
  addPage,
  removeCurrentPage,
  pagesCount,
  currentPageIndex,
  goToPage
}) {
  const [pageInput, setPageInput] = useState(currentPageIndex + 1);

  useEffect(() => {
    setPageInput(currentPageIndex + 1);
  }, [currentPageIndex]);

  const onPageChange = (e) => {
    const val = e.target.value;
    if (val === '') {
      setPageInput('');
      return;
    }
    const num = parseInt(val, 10);
    if (!isNaN(num) && num >= 1 && num <= pagesCount) {
      setPageInput(num);
      goToPage(num - 1);
    }
  };

  const onPageBlur = () => {
    if (pageInput === '' || pageInput < 1 || pageInput > pagesCount) {
      setPageInput(currentPageIndex + 1);
    }
  };

  const onPageSizeChange = (e) => {
    const size = e.target.value;
    if (pageSizes[size]) {
      changePageSize(pageSizes[size]);
    }
  };

  return (
    <ToolbarContainer>
      <Button onClick={() => addElement('text')} title="Add Text Box">
        Add Text
      </Button>
      <Button onClick={() => addElement('image')} title="Add Image">
        Add Image
      </Button>
      <Button onClick={() => addElement('shape')} title="Add Shape">
        Add Shape
      </Button>

      <Label htmlFor="pageSizeSelect">Page Size:</Label>
      <Select
        id="pageSizeSelect"
        value={
          Object.entries(pageSizes).find(
            ([, size]) =>
              size.width === pageSize.width && size.height === pageSize.height
          )?.[0] || 'Custom'
        }
        onChange={onPageSizeChange}
        title="Change Page Size"
      >
        {Object.entries(pageSizes).map(([key]) => (
          <option key={key} value={key}>
            {key}
          </option>
        ))}
        <option value="Custom" disabled>
          Custom
        </option>
      </Select>

      <Button onClick={addPage} title="Add New Page">
        + Page
      </Button>
      <Button
        onClick={removeCurrentPage}
        disabled={pagesCount <= 1}
        title="Remove Current Page"
      >
        - Page
      </Button>

      <PageNavigator>
        <Label htmlFor="pageNumberInput">Page:</Label>
        <Input
          id="pageNumberInput"
          type="number"
          min={1}
          max={pagesCount}
          value={pageInput}
          onChange={onPageChange}
          onBlur={onPageBlur}
          title="Go to Page"
        />
        <span>
          / {pagesCount}
        </span>
      </PageNavigator>
    </ToolbarContainer>
  );
}

export default Toolbar;
