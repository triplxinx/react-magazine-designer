import React, { useState } from 'react';
import styled from 'styled-components';
import { generatePDF } from '../utils/pdfGenerator';
import { saveAs } from 'file-saver';

const ExportContainer = styled.div`
  padding: 12px 16px;
  background: #2c3e50;
  display: flex;
  justify-content: flex-end;
`;

const Button = styled.button`
  background: #1abc9c;
  border: none;
  padding: 10px 18px;
  border-radius: 4px;
  color: white;
  font-weight: 700;
  font-size: 16px;
  cursor: pointer;

  &:hover,
  &:focus {
    background: #16a085;
    outline: none;
  }

  &:disabled {
    background: #7f8c8d;
    cursor: not-allowed;
  }
`;

function ExportButton({ pages, pageSize }) {
  const [isExporting, setIsExporting] = useState(false);

  const onExportClick = async () => {
    if (!pages.length) {
      alert('No pages to export.');
      return;
    }

    try {
      setIsExporting(true);
      const pdfBytes = await generatePDF(pages, pageSize);
      const blob = new Blob([pdfBytes], { type: 'application/pdf' });
      saveAs(blob, 'magazine-layout.pdf');
    } catch (error) {
      console.error('PDF generation error:', error);
      alert('Failed to export PDF. See console for details.');
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <ExportContainer>
      <Button onClick={onExportClick} disabled={isExporting} aria-label="Export magazine as PDF">
        {isExporting ? 'Exporting...' : 'Export PDF'}
      </Button>
    </ExportContainer>
  );
}

export default ExportButton;
