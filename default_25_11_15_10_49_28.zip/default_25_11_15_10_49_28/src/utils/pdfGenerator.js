import { jsPDF } from 'jspdf';

// Convert mm to pt for jsPDF (1mm = 2.83465pt)
const MM_TO_PT = 2.83465;

// Convert mm to pixels for layout calculations (unused here but may be useful)
const MM_TO_PX = 3.7795275591;

function mmToPt(mm) {
  return mm * MM_TO_PT;
}

// Helper to parse HTML text content from saved innerHTML (basic approach)
function parseTextContent(html) {
  const tmp = document.createElement('div');
  tmp.innerHTML = html;
  return tmp.textContent || tmp.innerText || '';
}

function drawText(pdf, el, dpiScale, pageMarginPt) {
  try {
    const x = mmToPt(el.x / dpiScale) + pageMarginPt;
    const y = mmToPt(el.y / dpiScale) + pageMarginPt;
    const width = mmToPt(el.width / dpiScale);
    const height = mmToPt(el.height / dpiScale);

    const content = parseTextContent(el.content);

    // Approximate font size scaling
    let fontSize = el.style?.fontSize || 12;
    fontSize = Math.max(6, Math.min(72, fontSize));
    pdf.setFontSize(fontSize);

    // Font style
    let fontStyle = 'normal';
    if (
      el.style?.fontWeight === 'bold' &&
      el.style?.fontStyle === 'italic'
    ) {
      fontStyle = 'bolditalic';
    } else if (el.style?.fontWeight === 'bold') {
      fontStyle = 'bold';
    } else if (el.style?.fontStyle === 'italic') {
      fontStyle = 'italic';
    }
    pdf.setFont('helvetica', fontStyle);

    // Color
    if (el.style?.color) {
      const rgb = hexToRgb(el.style.color);
      if (rgb) pdf.setTextColor(rgb.r, rgb.g, rgb.b);
    } else {
      pdf.setTextColor(0, 0, 0);
    }

    // Text align
    let align = 'left';
    switch (el.style?.textAlign) {
      case 'center':
        align = 'center';
        break;
      case 'right':
        align = 'right';
        break;
      case 'justify':
        align = 'justify';
        break;
      default:
        align = 'left';
    }

    // jsPDF multiline text
    pdf.text(content, x, y + fontSize, {
      maxWidth: width,
      align
    });
  } catch (err) {
    console.warn('Failed to draw text element', err);
  }
}

function drawImage(pdf, el, dpiScale, pageMarginPt) {
  try {
    const x = mmToPt(el.x / dpiScale) + pageMarginPt;
    const y = mmToPt(el.y / dpiScale) + pageMarginPt;
    const width = mmToPt(el.width / dpiScale);
    const height = mmToPt(el.height / dpiScale);

    if (!el.src) return;

    // jsPDF supports base64 images in DataURL format
    pdf.addImage(el.src, 'JPEG', x, y, width, height, undefined, 'FAST');
  } catch (err) {
    console.warn('Failed to draw image element', err);
  }
}

function drawShape(pdf, el, dpiScale, pageMarginPt) {
  try {
    const x = mmToPt(el.x / dpiScale) + pageMarginPt;
    const y = mmToPt(el.y / dpiScale) + pageMarginPt;
    const width = mmToPt(el.width / dpiScale);
    const height = mmToPt(el.height / dpiScale);

    const fillColor = el.fillColor ? hexToRgb(el.fillColor) : null;
    const strokeColor = el.strokeColor ? hexToRgb(el.strokeColor) : null;
    const strokeWidth = el.strokeWidth || 0;

    if (fillColor) {
      pdf.setFillColor(fillColor.r, fillColor.g, fillColor.b);
    }
    if (strokeColor) {
      pdf.setDrawColor(strokeColor.r, strokeColor.g, strokeColor.b);
    }
    pdf.setLineWidth(strokeWidth);

    switch (el.shapeType) {
      case 'rectangle':
        pdf.rect(x, y, width, height, fillColor ? 'FD' : 'S');
        break;
      case 'circle': {
        const cx = x + width / 2;
        const cy = y + height / 2;
        const r = Math.min(width, height) / 2;
        pdf.circle(cx, cy, r, fillColor ? 'FD' : 'S');
        break;
      }
      case 'line':
        pdf.line(x, y + height, x + width, y);
        break;
      default:
        pdf.rect(x, y, width, height, fillColor ? 'FD' : 'S');
        break;
    }
  } catch (err) {
    console.warn('Failed to draw shape element', err);
  }
}

// Convert hex color string to rgb object
function hexToRgb(hex) {
  if (!hex) return null;
  let c = hex.trim();
  if (c[0] === '#') c = c.substring(1);
  if (c.length === 3) {
    c = c[0] + c[0] + c[1] + c[1] + c[2] + c[2];
  }
  if (c.length !== 6) return null;
  const num = parseInt(c, 16);
  return {
    r: (num >> 16) & 255,
    g: (num >> 8) & 255,
    b: num & 255
  };
}

/**
 * Generate print-ready PDF from pages and pageSize
 * @param {Array} pages Array of pages with elements
 * @param {Object} pageSize {width: mm, height: mm, dpi: number, margin: mm}
 * @returns {Promise<Uint8Array>} PDF file bytes
 */
export async function generatePDF(pages, pageSize) {
  // DPI scale - converting px to mm factor for layout mapping
  // Our internal layout uses pixels based on dpi, so convert back from px to mm
  const dpi = pageSize.dpi || 300;
  const dpiScale = dpi / 25.4; // pixels per mm

  // Page dimensions in pt for jsPDF
  const pageWidthPt = mmToPt(pageSize.width);
  const pageHeightPt = mmToPt(pageSize.height);
  const marginPt = mmToPt(pageSize.margin || 0);

  const pdf = new jsPDF({
    unit: 'pt',
    format: [pageWidthPt, pageHeightPt]
  });

  for (let i = 0; i < pages.length; i++) {
    const page = pages[i];

    // White background
    pdf.setFillColor(255, 255, 255);
    pdf.rect(0, 0, pageWidthPt, pageHeightPt, 'F');

    // Draw elements on page
    for (const el of page.elements) {
      switch (el.type) {
        case 'text':
          drawText(pdf, el, dpiScale, marginPt);
          break;
        case 'image':
          drawImage(pdf, el, dpiScale, marginPt);
          break;
        case 'shape':
          drawShape(pdf, el, dpiScale, marginPt);
          break;
        default:
          break;
      }
    }

    if (i < pages.length - 1) {
      pdf.addPage();
    }
  }

  return pdf.output('arraybuffer');
}
